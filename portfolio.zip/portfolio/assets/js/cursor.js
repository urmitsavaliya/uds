/**
 * Advanced Coding Cursor Effect
 * Features:
 * - Trailing code snippets ({}, </>, 01, =>)
 * - Custom block cursor head (Terminal style)
 * - Fading animations
 */

(function() {
    const symbols = ['{', '}', '[]', '()', '=>', '0', '1', '</>', ';', 'const', 'var', 'let', 'func', 'async'];
    const colors = ['#6366f1', '#4f46e5', '#818cf8']; // Variations of primary color
    
    // Create cursor head
    const cursorHead = document.createElement('div');
    cursorHead.id = 'custom-cursor-head';
    Object.assign(cursorHead.style, {
        width: '12px',
        height: '20px',
        backgroundColor: '#6366f1',
        position: 'fixed',
        top: '0',
        left: '0',
        pointerEvents: 'none',
        zIndex: '10000',
        borderRadius: '2px',
        boxShadow: '0 0 10px rgba(99, 102, 241, 0.5)',
        transition: 'transform 0.05s ease-out',
        display: 'none' // Initially hidden until mouse moves
    });
    document.body.appendChild(cursorHead);

    let lastX = 0;
    let lastY = 0;

    function createParticle(x, y) {
        const particle = document.createElement('div');
        const symbol = symbols[Math.floor(Math.random() * symbols.length)];
        const color = colors[Math.floor(Math.random() * colors.length)];
        
        particle.textContent = symbol;
        Object.assign(particle.style, {
            position: 'fixed',
            left: x + 'px',
            top: y + 'px',
            pointerEvents: 'none',
            color: color,
            fontSize: (Math.random() * 8 + 10) + 'px',
            fontFamily: "'Fira Code', 'Courier New', monospace",
            fontWeight: '600',
            opacity: '0.8',
            zIndex: '9999',
            transition: 'all 1.2s cubic-bezier(0.1, 0.5, 0.2, 1)',
            textShadow: `0 0 5px ${color}`,
            whiteSpace: 'nowrap'
        });
        
        document.body.appendChild(particle);
        
        // Trigger animation
        requestAnimationFrame(() => {
            const angle = Math.random() * Math.PI * 2;
            const dist = Math.random() * 60 + 30;
            particle.style.transform = `translate(${Math.cos(angle) * dist}px, ${Math.sin(angle) * dist}px) rotate(${Math.random() * 90 - 45}deg)`;
            particle.style.opacity = '0';
            particle.style.fontSize = '4px';
        });
        
        setTimeout(() => particle.remove(), 1200);
    }

    document.addEventListener('mousemove', (e) => {
        if (cursorHead.style.display === 'none') cursorHead.style.display = 'block';
        
        cursorHead.style.transform = `translate(${e.clientX}px, ${e.clientY - 10}px)`;
        
        // Distance check to avoid too many particles
        const dist = Math.hypot(e.clientX - lastX, e.clientY - lastY);
        if (dist > 30) {
            createParticle(e.clientX, e.clientY);
            lastX = e.clientX;
            lastY = e.clientY;
        }
    });

    // Handle touch screens
    document.addEventListener('touchstart', () => {
        cursorHead.style.display = 'none';
    });
})();
